define([], function() {
	return {
		id: "world",
		gravity: 0.05
	};
});